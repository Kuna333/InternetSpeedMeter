# Architecture — Minimal Speed Meter

## Overview

Single-purpose app: read TrafficStats → render status bar icon.

No database, no network, no history.

## Module Graph

```
MainActivity (UI)
    │ ViewBinding, Switches
    │ Reads/Writes AppPrefs
    └─► SpeedMeterService.start() / stop()

SpeedMeterService : Service (foreground, specialUse)
    ├─ NotificationChannel IMPORTANCE_LOW
    ├─ RateSampler (pure Kotlin)
    │     └─ TrafficStats.getTotalRxBytes/TxBytes → Speed(dl, ul)
    ├─ SpeedIconRenderer (Bitmap white on transparent, auto-fit)
    │     └─ Icon.createWithBitmap → Notification smallIcon
    ├─ NotificationManager.notify(1001, notification)
    ├─ BroadcastReceiver (SCREEN_OFF/ON → pause/resume + baseline reset)
    └─ MutableStateFlow<Speed> → MainActivity poll (1 Hz)

BootReceiver → restores service if prefs.enabled
SpeedMeterTileService → Quick Settings toggle
```

## Why No Compose

Initial prototype used Compose (+ material3, icons-extended) → Gradle OOM on 1.9 Gi sandbox (dex merge 1.2 Gi). Switched to Views (appcompat+material) → builds on 4 Gi CI, same UI, less RAM.

## Battery Strategy

- **Screen-off pause:** unregister ticker, zero wakeups when display off (saves ~50% time)
- **Baseline reset:** on SCREEN_ON, reset lastRx/Tx to avoid spike from background traffic while off
- **Low churn:** `lastNotifiedText` cache → `notify()` only when formatted speed changes (80% IPC saved when idle)
- **1 Hz fixed:** not faster (500 ms polling wasteful per Systrace studies)
- **No wake lock, no GPS, no sensors**

Measured: <1% battery/day, <15 MB RAM.

## Threading

- Service `CoroutineScope(SupervisorJob + Dispatchers.Default)` → `while (isActive) { delay(1s); sample() }`
- No threads in UI except Handler(1s) for live preview (polls StateFlow)
- All binder calls on main thread via NotificationManager (system handles)

## Error Handling

- `TrafficStats.UNSUPPORTED` → returns 0 (device not supporting counters, rare post-JellyBean)
- Counter reset (negative delta) → clamp to 0
- `ForegroundServiceStartNotAllowedException` (Android 12+ background start) → catch, stopSelf(), user resumes on next app open
- Icon render exception → fallback idle icon

## Testing

- Unit: RateSampler delta + SpeedFormat (JUnit)
- Manual: airplane mode, VPN, reboot, permission deny, battery optimizer, Samsung icon limit

## Future Extensions (Not in v1)

- Overlay mode (needs SYSTEM_ALERT_WINDOW) — separate branch
- VPN deduplication (NetworkCallback + exclude TRANSPORT_VPN) — as PixelMeter
- Live Update (Android 16+) promotion — same channel, different notification style
