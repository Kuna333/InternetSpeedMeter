# Privacy Policy — Minimal Internet Speed Meter

**No data leaves your device. Ever.**

---

## Data Collection: None

This app:

- Does **not** collect personal information
- Does **not** track you
- Does **not** use analytics, ads, or crash reporting
- Does **not** have internet access (no `INTERNET` permission)
- Does **not** read contacts, location, files, or app content

## What It Does Access

1. **Traffic counters** (`TrafficStats.getTotalRxBytes()` / `getTotalTxBytes()`) — system byte counts since boot. No per-app, per-site, or content detail.
2. **Notification system** — to display the speed icon. The notification icon is the status bar speed.
3. **Boot signal** — to restore your ON/OFF choice after restart (if you had it ON).

All processing is in RAM, discarded next second. Only 3 preference keys persist: `enabled`, `use_bits`, `show_upload`.

## Permissions Justification

| Permission | Needed | Why | Privacy Risk |
|---|---|---|---|
| `POST_NOTIFICATIONS` | Yes (Android 13+) | Show status bar icon | None |
| `FOREGROUND_SERVICE[_SPECIAL_USE]` | Yes | Keep service running | None |
| `RECEIVE_BOOT_COMPLETED` | Yes | Restore state after reboot | None |
| `INTERNET` | **No** | Not requested, not needed | Zero exfiltration possible |
| `LOCATION`, `CONTACTS`, `CAMERA`, etc. | **No** | Never requested | — |

## Verification

```bash
# 1. Check manifest
cat app/src/main/AndroidManifest.xml | grep uses-permission
# → 4 lines only

# 2. Check built APK
aapt dump permissions app-debug.apk
# → should NOT contain android.permission.INTERNET

# 3. Check dependencies
./gradlew dependencies --configuration releaseRuntimeClasspath
# → only androidx.* and kotlin.stdlib

# 4. Offline test
# Turn on airplane mode → app shows "↓ 0 B/s" (proves no server)
```

## Third-Party Code

None. No SDKs, no analytics, no ads. Only AndroidX libraries from Google.

## Open Source

Built transparently. Audit any file — all logic in `SpeedMeterService.kt` + `RateSampler.kt`.

## Contact

Issues via GitHub (no email collection).

---

*If this privacy policy ever changes, the version bump will be visible in GitHub history.*

