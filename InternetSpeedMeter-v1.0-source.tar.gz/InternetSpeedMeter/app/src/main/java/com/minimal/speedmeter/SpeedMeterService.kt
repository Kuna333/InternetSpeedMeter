package com.minimal.speedmeter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Minimal foreground service that:
 * - Samples TrafficStats at 1 Hz (only while screen ON for battery)
 * - Renders status bar icon as notification smallIcon bitmap
 * - Shows full speeds in notification shade with Stop action
 * - Pauses on screen off, resets baseline on screen on (no spike)
 * - Updates notification only when text changes (low churn)
 *
 * No wake lock, no internet, no analytics.
 */
class SpeedMeterService : Service() {

    companion object {
        const val CHANNEL_ID = "speed_meter_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.minimal.speedmeter.STOP"

        // Companion state for Activity binding via singleton pattern
        // For minimal app, Activity polls via startService + broadcast; we also expose via static flow
        private val _speedState = MutableStateFlow(Speed(0.0, 0.0))
        val speedState: StateFlow<Speed> = _speedState

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning

        fun start(context: Context) {
            val intent = Intent(context, SpeedMeterService::class.java)
            androidx.core.content.ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, SpeedMeterService::class.java))
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var tickerJob: Job? = null

    private lateinit var notificationManager: NotificationManager
    private lateinit var prefs: AppPrefs
    private val sampler = RateSampler()

    // Screen state tracking
    private var screenOn = true
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    screenOn = false
                    pauseTicker()
                }
                Intent.ACTION_SCREEN_ON -> {
                    screenOn = true
                    sampler.resetBaseline() // prevent spike from data used while screen off
                    resumeTicker()
                }
            }
        }
    }

    // Low-churn: remember last notified text to avoid redundant Binder IPC
    private var lastNotifiedText: String? = null
    private var lastIconLine1: String? = null
    private var lastIconLine2: String? = null

    override fun onCreate() {
        super.onCreate()
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        prefs = AppPrefs(this)
        createChannel()

        // Register screen on/off for battery optimization
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        registerReceiver(screenReceiver, filter)

        _isRunning.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Build initial notification and promote to foreground immediately (within 5 sec requirement)
        val initialNotification = buildNotification(Speed(0.0, 0.0), "↓ 0 B/s ↑ 0 B/s")
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    initialNotification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                ServiceCompat.startForeground(this, NOTIFICATION_ID, initialNotification, 0)
            }
        } catch (e: Exception) {
            // Fallback for strict OEMs that may throw ForegroundServiceStartNotAllowedException
            // if started from background; we just notify and stop
            e.printStackTrace()
            stopSelf()
            return START_NOT_STICKY
        }

        // Start ticker
        resumeTicker()

        return START_STICKY
    }

    private fun pauseTicker() {
        tickerJob?.cancel()
        tickerJob = null
        _speedState.value = Speed(0.0, 0.0)
    }

    private fun resumeTicker() {
        if (tickerJob?.isActive == true) return
        tickerJob = serviceScope.launch {
            // Reset baseline on resume so screen-off traffic doesn't spike
            // already done in receiver, but ensure
            while (isActive) {
                if (screenOn) {
                    val speed = sampler.sample()
                    _speedState.value = speed
                    updateNotificationIfNeeded(speed)
                }
                delay(1000L) // 1 Hz standard (battery-efficient vs 500ms)
            }
        }
    }

    private fun updateNotificationIfNeeded(speed: Speed) {
        val useBits = prefs.useBits
        val showUpload = prefs.showUpload

        val fullText = SpeedFormat.formatFull(speed.downloadBps, speed.uploadBps, useBits)
        val (line1, line2) = SpeedFormat.formatIconLines(speed.downloadBps, speed.uploadBps, useBits, showUpload)

        // Low churn: skip if nothing visible changed
        if (fullText == lastNotifiedText && line1 == lastIconLine1 && line2 == lastIconLine2) {
            return
        }
        lastNotifiedText = fullText
        lastIconLine1 = line1
        lastIconLine2 = line2

        val notification = buildNotification(speed, fullText, line1, line2)
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(
        speed: Speed,
        fullText: String,
        line1: String = "0",
        line2: String = ""
    ): Notification {
        // For status bar icon: render current speed as bitmap
        val bitmap = try {
            if (line1 == "0" && line2.isEmpty()) SpeedIconRenderer.renderIdle(this)
            else SpeedIconRenderer.render(this, line1, line2)
        } catch (e: Exception) {
            SpeedIconRenderer.renderIdle(this)
        }

        val icon = Icon.createWithBitmap(bitmap)

        // Tap notification -> open app
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Stop action
        val stopIntent = Intent(this, SpeedMeterService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // For Android 14+ promoted notification style, keep it simple
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(icon)
            .setContentTitle(fullText)
            .setContentText(if (prefs.showUpload) "Live • Download top / Upload bottom" else "Live download speed")
            .setContentIntent(openPending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_delete),
                    getString(R.string.stop),
                    stopPending
                ).build()
            )

        // On older, set priority via compat
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // channel handles importance
        }

        return builder.build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW // no sound, shows icon
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
                enableVibration(false)
                setSound(null, null)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        tickerJob?.cancel()
        serviceScope.cancel()
        _isRunning.value = false
        // Cancel notification (status bar icon goes away)
        notificationManager.cancel(NOTIFICATION_ID)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
