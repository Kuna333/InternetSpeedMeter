package com.minimal.speedmeter

import java.util.Locale
import kotlin.math.abs

/**
 * Formatting for two contexts:
 * 1. Notification shade: full string like "↓ 1.2 MB/s ↑ 300 KB/s" or "12.4 Mbps"
 * 2. Status bar icon: compact 4-char per line like "1.2M" "300K"
 */
object SpeedFormat {

    /**
     * Full human-readable for notification content and UI.
     * Example: "↓ 1.2 MB/s ↑ 340 KB/s" or in bits: "↓ 9.6 Mbps ↑ 2.4 Mbps"
     */
    fun formatFull(downloadBps: Double, uploadBps: Double, useBits: Boolean): String {
        return if (useBits) {
            "↓ ${formatBits(downloadBps * 8)} ↑ ${formatBits(uploadBps * 8)}"
        } else {
            "↓ ${formatBytes(downloadBps)} ↑ ${formatBytes(uploadBps)}"
        }
    }

    fun formatBytes(bytesPerSec: Double): String {
        if (bytesPerSec < 1024) return "${bytesPerSec.toInt()} B/s"
        val kb = bytesPerSec / 1024.0
        if (kb < 1024) return String.format(Locale.US, "%.1f KB/s", kb).replace(".0 KB/s", " KB/s")
        val mb = kb / 1024.0
        if (mb < 1024) return String.format(Locale.US, "%.1f MB/s", mb).replace(".0 MB/s", " MB/s")
        val gb = mb / 1024.0
        return String.format(Locale.US, "%.1f GB/s", gb)
    }

    fun formatBits(bitsPerSec: Double): String {
        if (bitsPerSec < 1000) return "${bitsPerSec.toInt()} b/s"
        val kb = bitsPerSec / 1000.0
        if (kb < 1000) return String.format(Locale.US, "%.1f Kbps", kb).replace(".0 Kbps", " Kbps")
        val mb = kb / 1000.0
        if (mb < 1000) return String.format(Locale.US, "%.1f Mbps", mb).replace(".0 Mbps", " Mbps")
        val gb = mb / 1000.0
        return String.format(Locale.US, "%.1f Gbps", gb)
    }

    /**
     * Compact 4-char max for status bar icon rendering.
     * Examples: "0", "12K", "1.2M", "34M", "1.1G"
     * Uses bytes or bits depending on setting.
     */
    fun formatCompact(bytesPerSec: Double, useBits: Boolean): String {
        val value = if (useBits) bytesPerSec * 8 else bytesPerSec
        val unitDivisor = if (useBits) 1000.0 else 1024.0

        return when {
            value < unitDivisor -> {
                // e.g., 512, 0
                if (useBits && value >= 1000) formatCompact(value / unitDivisor, false) // fallback
                else value.toInt().toString().take(4)
            }
            value < 10 * unitDivisor -> {
                // e.g., 1.2K, 9.6M
                val v = value / unitDivisor
                String.format(Locale.US, "%.1fK", v).replace("K", if (useBits) "K" else "K").take(4)
                    .let { if (it.endsWith(".0K")) it.replace(".0K", "K") else it }
            }
            value < 100 * unitDivisor -> {
                val v = value / unitDivisor
                // 12K -> "12K"
                "${v.toInt()}K".take(4)
            }
            value < 1000 * unitDivisor -> {
                val v = value / unitDivisor
                "${v.toInt()}K".take(4)
            }
            else -> {
                // MB range
                val mb = value / (unitDivisor * unitDivisor)
                when {
                    mb < 10 -> String.format(Locale.US, "%.1fM", mb).let { if (it.endsWith(".0M")) it.replace(".0M", "M") else it }
                    mb < 1000 -> "${mb.toInt()}M"
                    else -> {
                        val gb = mb / unitDivisor
                        if (gb < 10) String.format(Locale.US, "%.1fG", gb) else "${gb.toInt()}G"
                    }
                }.take(4)
            }
        }
    }

    /**
     * Icon needs two lines: download on top, upload below.
     * Returns pair (line1, line2)
     */
    fun formatIconLines(downloadBps: Double, uploadBps: Double, useBits: Boolean, showUpload: Boolean): Pair<String, String> {
        val dl = formatCompact(downloadBps, useBits)
        return if (showUpload) {
            val ul = formatCompact(uploadBps, useBits)
            Pair(dl, ul)
        } else {
            // Single line centered - we still return two lines, second empty (renderer handles)
            Pair(dl, "")
        }
    }
}
