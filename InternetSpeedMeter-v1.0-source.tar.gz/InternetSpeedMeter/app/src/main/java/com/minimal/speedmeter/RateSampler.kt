package com.minimal.speedmeter

import android.net.TrafficStats
import android.os.SystemClock

/**
 * Pure, testable rate calculation.
 * Reads system counters, computes delta / elapsed time.
 * Handles: UNSUPPORTED, counter reset (e.g., airplane toggle), negative deltas.
 */
data class Speed(
    val downloadBps: Double, // bytes per second
    val uploadBps: Double
) {
    val isIdle: Boolean get() = downloadBps < 1.0 && uploadBps < 1.0
}

class RateSampler {

    private var lastRxBytes: Long = TrafficStats.getTotalRxBytes()
    private var lastTxBytes: Long = TrafficStats.getTotalTxBytes()
    private var lastTimeNanos: Long = SystemClock.elapsedRealtimeNanos()

    // Baseline reset is called on screen-on to avoid spike from data used while screen off
    fun resetBaseline() {
        lastRxBytes = TrafficStats.getTotalRxBytes().coerceAtLeast(0)
        lastTxBytes = TrafficStats.getTotalTxBytes().coerceAtLeast(0)
        lastTimeNanos = SystemClock.elapsedRealtimeNanos()
    }

    fun sample(): Speed {
        val nowRx = TrafficStats.getTotalRxBytes()
        val nowTx = TrafficStats.getTotalTxBytes()
        val nowTime = SystemClock.elapsedRealtimeNanos()

        // Handle UNSUPPORTED (returns -1 via TrafficStats.UNSUPPORTED which is Long)
        if (nowRx == TrafficStats.UNSUPPORTED.toLong() || nowTx == TrafficStats.UNSUPPORTED.toLong()) {
            lastRxBytes = if (nowRx == TrafficStats.UNSUPPORTED.toLong()) 0 else nowRx
            lastTxBytes = if (nowTx == TrafficStats.UNSUPPORTED.toLong()) 0 else nowTx
            lastTimeNanos = nowTime
            return Speed(0.0, 0.0)
        }

        val dtSec = (nowTime - lastTimeNanos) / 1_000_000_000.0
        if (dtSec <= 0.0) return Speed(0.0, 0.0)

        // Delta, clamped to >=0 (counter reset on reboot/interface change yields negative)
        val rxDelta = (nowRx - lastRxBytes).coerceAtLeast(0)
        val txDelta = (nowTx - lastTxBytes).coerceAtLeast(0)

        val speed = Speed(
            downloadBps = rxDelta / dtSec,
            uploadBps = txDelta / dtSec
        )

        lastRxBytes = nowRx
        lastTxBytes = nowTx
        lastTimeNanos = nowTime

        return speed
    }
}
