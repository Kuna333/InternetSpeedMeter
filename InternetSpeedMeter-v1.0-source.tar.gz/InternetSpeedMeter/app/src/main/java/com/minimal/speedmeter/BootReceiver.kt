package com.minimal.speedmeter

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Auto-restart after reboot or app update.
 * Respects user's ON/OFF preference - only restarts if previously enabled.
 * Handles Android 12+ background start restrictions by checking preference;
 * if system blocks, meter will resume on next app open (documented limitation).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == Intent.ACTION_REBOOT
        ) {
            val prefs = AppPrefs(context)
            if (prefs.isEnabled) {
                try {
                    SpeedMeterService.start(context)
                } catch (e: Exception) {
                    // On Android 12+, starting FGS from background without user trigger
                    // can throw ForegroundServiceStartNotAllowedException.
                    // We log and let user resume on next app open.
                    e.printStackTrace()
                }
            }
        }
    }
}
