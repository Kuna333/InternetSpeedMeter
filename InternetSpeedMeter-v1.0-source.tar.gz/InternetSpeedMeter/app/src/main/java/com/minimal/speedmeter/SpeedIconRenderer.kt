package com.minimal.speedmeter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.util.TypedValue
import androidx.core.graphics.createBitmap

/**
 * Renders speed into a small notification icon bitmap.
 * Android treats smallIcon as alpha mask and tints it, so we draw WHITE on TRANSPARENT.
 * Size: 24dp as recommended for status bar icons, rendered at xhdpi density.
 */
object SpeedIconRenderer {

    // Reuse Paint for efficiency
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt() // white (alpha mask)
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val secondaryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFCCCCCC.toInt()
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        textAlign = Paint.Align.CENTER
    }

    /**
     * Creates a 24dp bitmap with one or two lines of speed text.
     * line1 = download (top), line2 = upload (bottom) or empty.
     */
    fun render(context: Context, line1: String, line2: String): Bitmap {
        val density = context.resources.displayMetrics.density
        // 24dp standard status bar icon size, but we use 72px (24dp * 3 for crisp on xxxhdpi)
        // Pepperonas uses 96x96 ALPHA_8; we use ARGB_8888 96x96 for widest compatibility
        val size = (24 * density * 3).toInt().coerceAtLeast(96)
        val bitmap = createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Clear transparent
        canvas.drawColor(0x00000000)

        if (line2.isEmpty()) {
            // Single line centered
            val textSize = fitTextSize(line1, size * 0.85f, 10f * density, 18f * density)
            textPaint.textSize = textSize
            val y = size / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
            canvas.drawText(line1, size / 2f, y, textPaint)
        } else {
            // Two lines: download top, upload bottom
            // Top line slightly larger/bolder, bottom slightly smaller
            val topSize = fitTextSize(line1, size * 0.85f, 9f * density, 15f * density)
            val bottomSize = fitTextSize(line2, size * 0.85f, 8f * density, 13f * density)

            textPaint.textSize = topSize
            // Top line at 35% height
            val y1 = size * 0.38f - (textPaint.descent() + textPaint.ascent()) / 2f
            canvas.drawText(line1, size / 2f, y1, textPaint)

            textPaint.textSize = bottomSize
            val y2 = size * 0.78f - (textPaint.descent() + textPaint.ascent()) / 2f
            // Slightly dimmer for upload to distinguish visually
            // But still white for alpha mask; use same paint (alpha mask doesn't support dimming well)
            canvas.drawText(line2, size / 2f, y2, textPaint)
        }

        // Optional: draw tiny arrow indicators via unicode? Not needed - lines imply ↓/↑ by position
        // Download on top, upload below matches convention

        return bitmap
    }

    /**
     * Simple binary search to fit text within available width.
     */
    private fun fitTextSize(text: String, maxWidth: Float, minSize: Float, maxSize: Float): Float {
        var low = minSize
        var high = maxSize
        var best = minSize
        repeat(8) {
            val mid = (low + high) / 2f
            textPaint.textSize = mid
            val w = textPaint.measureText(text)
            if (w <= maxWidth) {
                best = mid
                low = mid + 0.5f
            } else {
                high = mid - 0.5f
            }
        }
        return best
    }

    /**
     * Fallback static icon when idle or 0 - shows "0" or minimal
     */
    fun renderIdle(context: Context): Bitmap {
        return render(context, "0", "")
    }
}
