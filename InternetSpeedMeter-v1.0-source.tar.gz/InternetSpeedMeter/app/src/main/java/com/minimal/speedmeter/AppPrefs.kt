package com.minimal.speedmeter

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

/**
 * Minimal persistence: only 3 keys.
 * No cloud sync, no history, no database.
 */
class AppPrefs(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("speed_meter_prefs", Context.MODE_PRIVATE)

    var isEnabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, false)
        set(value) = prefs.edit { putBoolean(KEY_ENABLED, value) }

    var useBits: Boolean
        get() = prefs.getBoolean(KEY_USE_BITS, false)
        set(value) = prefs.edit { putBoolean(KEY_USE_BITS, value) }

    var showUpload: Boolean
        get() = prefs.getBoolean(KEY_SHOW_UPLOAD, true)
        set(value) = prefs.edit { putBoolean(KEY_SHOW_UPLOAD, value) }

    companion object {
        private const val KEY_ENABLED = "enabled"
        private const val KEY_USE_BITS = "use_bits"
        private const val KEY_SHOW_UPLOAD = "show_upload"
    }
}
