package com.minimal.speedmeter

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.card.MaterialCardView
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: AppPrefs
    private lateinit var switchEnable: SwitchMaterial
    private lateinit var switchBits: SwitchMaterial
    private lateinit var switchUpload: SwitchMaterial
    private lateinit var tvDownload: TextView
    private lateinit var tvUpload: TextView
    private lateinit var tvDownloadIcon: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvIdleBadge: TextView
    private lateinit var cardPermission: MaterialCardView
    private lateinit var tvVersion: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val updateRunnable = object : Runnable {
        override fun run() {
            updateLiveSpeed()
            handler.postDelayed(this, 1000)
        }
    }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        updatePermissionCard()
        if (granted && prefs.isEnabled) {
            SpeedMeterService.start(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = AppPrefs(this)
        setContentView(R.layout.activity_main)

        switchEnable = findViewById(R.id.switchEnable)
        switchBits = findViewById(R.id.switchBits)
        switchUpload = findViewById(R.id.switchUpload)
        tvDownload = findViewById(R.id.tvDownload)
        tvUpload = findViewById(R.id.tvUpload)
        tvDownloadIcon = findViewById(R.id.tvDownloadIcon)
        tvStatus = findViewById(R.id.tvStatus)
        tvIdleBadge = findViewById(R.id.tvIdleBadge)
        cardPermission = findViewById(R.id.cardPermission)
        tvVersion = findViewById(R.id.tvVersion)

        // Init switches from prefs
        switchEnable.isChecked = prefs.isEnabled
        switchBits.isChecked = prefs.useBits
        switchUpload.isChecked = prefs.showUpload

        // Listeners
        switchEnable.setOnCheckedChangeListener { _, checked ->
            prefs.isEnabled = checked
            if (checked) {
                if (!hasNotificationPermission() && Build.VERSION.SDK_INT >= 33) {
                    requestNotificationPermission()
                }
                SpeedMeterService.start(this)
            } else {
                SpeedMeterService.stop(this)
            }
            updateStatusText()
        }

        switchBits.setOnCheckedChangeListener { _, checked ->
            prefs.useBits = checked
        }

        switchUpload.setOnCheckedChangeListener { _, checked ->
            prefs.showUpload = checked
        }

        findViewById<View>(R.id.btnGrant).setOnClickListener {
            requestNotificationPermission()
        }
        findViewById<View>(R.id.btnSettings).setOnClickListener {
            openNotificationSettings()
        }

        // Version
        try {
            val pInfo = packageManager.getPackageInfo(packageName, 0)
            tvVersion.text = "v${pInfo.versionName} • No Internet Permission • ${getString(R.string.notification_channel_name)}"
        } catch (_: Exception) {}

        updatePermissionCard()
        updateStatusText()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionCard()
        updateStatusText()
        handler.post(updateRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(updateRunnable)
    }

    private fun updateLiveSpeed() {
        val speed = SpeedMeterService.speedState.value
        val isEnabled = prefs.isEnabled
        val useBits = prefs.useBits

        if (!isEnabled) {
            tvDownload.text = "Meter is OFF"
            tvDownload.setTextColor(0xFF6B7280.toInt())
            tvDownloadIcon.visibility = View.GONE
            tvUpload.text = "Toggle above to start"
            tvUpload.setTextColor(0xFF9CA3AF.toInt())
            tvIdleBadge.visibility = View.GONE
            return
        }

        val dlText = if (useBits) SpeedFormat.formatBits(speed.downloadBps * 8) else SpeedFormat.formatBytes(speed.downloadBps)
        val ulText = if (useBits) SpeedFormat.formatBits(speed.uploadBps * 8) else SpeedFormat.formatBytes(speed.uploadBps)

        tvDownloadIcon.visibility = View.VISIBLE
        tvDownloadIcon.text = "↓"
        tvDownload.text = dlText
        tvDownload.setTextColor(0xFF1A1A1A.toInt())

        tvUpload.text = "↑ $ulText"
        tvUpload.setTextColor(0xFF4B5563.toInt())

        tvIdleBadge.visibility = if (speed.isIdle) View.VISIBLE else View.GONE
    }

    private fun updateStatusText() {
        val enabled = prefs.isEnabled
        val running = SpeedMeterService.isRunning.value
        tvStatus.text = when {
            !enabled -> "Stopped"
            !running -> "Starting…"
            else -> "Running in status bar"
        }
        tvStatus.setTextColor(
            if (enabled) 0xFF00C853.toInt() else 0xFF9CA3AF.toInt()
        )
    }

    private fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= 33) {
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = nm.getNotificationChannel(SpeedMeterService.CHANNEL_ID)
                channel?.importance != android.app.NotificationManager.IMPORTANCE_NONE
            } else true
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun openNotificationSettings() {
        try {
            val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            }
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun updatePermissionCard() {
        cardPermission.visibility = if (!hasNotificationPermission()) View.VISIBLE else View.GONE
    }
}
