# Keep service and receivers
-keep class com.minimal.speedmeter.** { *; }
