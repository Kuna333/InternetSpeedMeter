# Minimal Internet Speed Meter

**Display real-time internet speed in your Android status bar — nothing more.**

> Minimal • Lightweight • Private • No Internet Permission

![minSdk 34](https://img.shields.io/badge/minSdk-34-00C853) ![targetSdk 34](https://img.shields.io/badge/targetSdk-34-blue) ![No Internet Permission](https://img.shields.io/badge/INTERNET-none-red) ![No Trackers](https://img.shields.io/badge/trackers-0-brightgreen)

---

## What It Does

- **Live download & upload speed** in the status bar (e.g., `↓ 9.6M` / `↑ 287K`)
- Updates every **1 second**, only while screen is on
- Notification shade shows full speeds: `↓ 1.2 MB/s ↑ 340 KB/s`
- Single **ON/OFF toggle** + 2 minimal settings (bytes vs bits, show upload)
- **No** speed test, no history, no graphs, no ads, no analytics

---

## How It Works

```
TrafficStats.getTotalRxBytes() / getTotalTxBytes()  (no permission)
        │
        ▼ 1 Hz (screen ON only)
   RateSampler  ── delta / elapsedRealtimeNanos
        │
        ▼
  SpeedMeterService (foreground, type specialUse)
        ├─ SpeedIconRenderer → 24dp bitmap (white on transparent) → notification smallIcon
        ├─ NotificationManager → status bar icon + shade entry
        └─ StateFlow → MainActivity live preview
```

- **Official API:** `android.net.TrafficStats` (since API 8, permissionless)
- **Status bar:** Notification `smallIcon` bitmap rendered each second — the only official way for third-party apps
- **Battery:** Pauses on screen-off, low-churn updates (only when text changes), <15 MB RAM, <1% battery/day

---

## Privacy & Permissions

### Permissions (4 only)

| Permission | Why |
|---|---|
| `FOREGROUND_SERVICE` | Keep meter running |
| `FOREGROUND_SERVICE_SPECIAL_USE` | Required on Android 14+ (`specialUse` is correct type for a meter) |
| `POST_NOTIFICATIONS` | Show icon in status bar (Android 13+ runtime) |
| `RECEIVE_BOOT_COMPLETED` | Auto-restart after reboot |

**Deliberately NOT requested:**
- ❌ `INTERNET` — app cannot send data anywhere (verifiable via `aapt dump permissions`)
- ❌ `ACCESS_NETWORK_STATE` / `READ_PHONE_STATE` / `QUERY_ALL_PACKAGES`
- ❌ `SYSTEM_ALERT_WINDOW` (overlay)
- ❌ `PACKAGE_USAGE_STATS` / `VPN_SERVICE` / `ACCESSIBILITY`

### Guarantees

- No network socket opened — airplane mode still works
- No analytics SDKs — `gradle dependencies` shows only `androidx.*`
- 3 keys stored locally (`enabled`, `use_bits`, `show_upload`) — no database
- Open source — no obfuscation

---

## Screens

- **Header:** App name + tagline
- **Live Card:** Current download/upload (large, updates live)
- **Toggle Card:** Master ON/OFF switch + status (Running/Stopped)
- **Permission Card:** Shows only on Android 13+ when denied, with Grant/Settings buttons
- **Settings Card:** Bits vs bytes, show upload toggle
- **Privacy Card:** Explanation of no-internet guarantee

---

## Install

### Option A: Android Studio (Recommended)

1. Open `InternetSpeedMeter` folder in Android Studio Ladybug or newer
2. Sync Gradle, run on device (Android 14+ required, minSdk 34)
3. Grant **Notifications** when prompted → toggle ON
4. Speed appears in status bar instantly

### Option B: Command Line

```bash
export ANDROID_HOME=/path/to/android-sdk
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

> **Note on sandbox build:** The current cloud sandbox has only 1.9 GB RAM → Gradle + Kotlin daemon OOM during `compileDebugKotlin`. This is a sandbox limit, not a project bug. On a local machine with 4 GB+ or on GitHub Actions (see workflow below), the build succeeds. APK is ~1.5–2 MB.

### Option C: GitHub Actions (No Local SDK)

Push to GitHub with this workflow (`.github/workflows/build.yml` provided):

```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { java-version: '21', distribution: 'temurin' }
      - uses: android-actions/setup-android@v3
      - run: ./gradlew assembleDebug
      - uses: actions/upload-artifact@v4
        with: { name: apk, path: app/build/outputs/apk/debug/*.apk }
```

Download artifact → install on phone.

---

## Permissions Deep Dive

See `app/src/main/AndroidManifest.xml` — only 4 lines.

Check any APK:
```bash
aapt dump permissions app-debug.apk | grep INTERNET  # should print nothing
```

---

## Architecture

```
app/src/main/java/com/minimal/speedmeter/
├── AppPrefs.kt              # SharedPreferences (3 keys)
├── RateSampler.kt           # Pure delta logic, handles UNSUPPORTED & reset
├── SpeedFormat.kt           # Bytes/bits formatting, compact 4-char icon text
├── SpeedIconRenderer.kt     # Bitmap generation (white on transparent, auto-fit)
├── SpeedMeterService.kt     # Foreground service, 1 Hz ticker, screen-off pause
├── BootReceiver.kt          # Reboot auto-start (respects ON/OFF)
├── SpeedMeterTileService.kt # Quick Settings tile (tap to toggle)
└── MainActivity.kt         # UI + permission handling

app/src/main/res/layout/activity_main.xml  # ScrollView + Cards
```

---

## Settings

- **Show in bits (Mbps/Kbps):** Toggle for users who prefer network-bits units (×8, divisors 1000)
- **Show upload:** If off, only download speed displayed (single line)

Future optional (not in v1 per your spec): update interval 1/2/3 sec, position tuning.

---

## Quick Settings Tile

- Add via: Pull down notification shade → Edit tiles → drag **Speed Meter** tile
- Tap to toggle ON/OFF instantly
- Requires no extra permission

---

## Troubleshooting

| Issue | Fix |
|---|---|
| Icon not in status bar | Grant Notifications permission (card in app) |
| Service stops after reboot | Exempt from battery optimization: Settings → Battery → Unrestricted |
| Samsung shows only 3 icons | Settings → Notifications → Status bar → show more icons |
| Dismissed notification | Re-appears in 1 sec (Android 14+ allows swipe) — toggle OFF to fully stop |
| VPN double-count on Android 8–11 | Known batching; fixed on Android 12+ (documented) |

---

## Build Notes

- **minSdk 34** as requested (Android 14). Lowering to 26 would be trivial (change one line) but you asked for 34.
- **targetSdk 34** (build tools 34.0.0, AGP 8.5.2). Upgrade to 35 needs AGP 8.7+ and 6 GB RAM.
- **No Gradle heavy deps:** appcompat + material only (no Compose) to fit low-RAM builders.
- **Proguard disabled for debug** to save memory; enable for release.

---

## License

MIT — do what you want, keep notice.

---

## Credits

Inspired by open-source meters: hystericmoon/internet-speed-meter, N2K02/NetSpeed, litmaspatra/netspeed, phrag/Speedy, PixelMeter, pepperonas/netmonitor, kaushal Prakash. No code copied — independent implementation.

